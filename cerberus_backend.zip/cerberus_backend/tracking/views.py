from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from .models import Viagem

@login_required
def home(request):
    user = request.user
    if user.user_type == 'supervisor':
        viagens = Viagem.objects.filter(status='em andamento')
        return render(request, 'supervisor_dashboard.html', {'viagens': viagens})
    elif user.user_type == 'motorista':
        return render(request, 'motorista_dashboard.html')
    return redirect('logout')  # Caso o tipo de usuário seja inválido, redireciona para logout

