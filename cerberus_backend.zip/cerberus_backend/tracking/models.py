from django.db import models
from django.contrib.auth.models import AbstractUser, Group, Permission


class CustomUser(AbstractUser):
    USER_TYPES = (
        ('supervisor', 'Supervisor'),
        ('motorista', 'Motorista'),
    )
    user_type = models.CharField(max_length=20, choices=USER_TYPES, default='motorista')

    groups = models.ManyToManyField(
        Group,
        related_name="customuser_groups",  # Nome exclusivo para evitar conflito
        blank=True,
        help_text="Os grupos aos quais o usuário pertence.",
        verbose_name="grupos",
    )
    user_permissions = models.ManyToManyField(
        Permission,
        related_name="customuser_permissions",  # Nome exclusivo para evitar conflito
        blank=True,
        help_text="Permissões específicas para o usuário.",
        verbose_name="permissões de usuário",
    )

    def __str__(self):
        return self.username


class Veiculo(models.Model):
    STATUS_CHOICES = [
        ('em manutenção', 'Em manutenção'),
        ('em revisão', 'Em revisão'),
        ('disponível', 'Disponível'),
    ]

    placa = models.CharField(max_length=10, unique=True)
    modelo = models.CharField(max_length=50)
    odometro = models.IntegerField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='disponível')

    def __str__(self):
        return f"{self.modelo} - {self.placa}"


class Supervisor(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, limit_choices_to={'user_type': 'supervisor'})
    matricula = models.CharField(max_length=12, unique=True)

    def __str__(self):
        return self.user.username


class Motorista(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, limit_choices_to={'user_type': 'motorista'})
    matricula = models.CharField(max_length=12, unique=True)
    cnh = models.CharField(max_length=12, unique=True)
    categoria = models.CharField(max_length=2)
    validade_cnh = models.DateField()
    ativo = models.BooleanField(default=True)

    def __str__(self):
        return self.user.username


class Viagem(models.Model):
    STATUS_CHOICES = [
        ('em andamento', 'Em andamento'),
        ('finalizada', 'Finalizada'),
        ('agendada', 'Agendada'),
        ('cancelada', 'Cancelada'),
    ]

    motorista = models.ForeignKey(Motorista, on_delete=models.CASCADE)
    veiculo = models.ForeignKey(Veiculo, on_delete=models.CASCADE)
    destino = models.CharField(max_length=255)
    odometro_inicial = models.IntegerField()
    data_partida = models.DateTimeField()
    odometro_final = models.IntegerField(null=True, blank=True)
    data_chegada = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='agendada')

    def __str__(self):
        return f"{self.destino} - {self.status}"
